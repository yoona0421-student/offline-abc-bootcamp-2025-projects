// server.js
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const { OpenAI } = require('openai');

dotenv.config(); // .env 파일에서 OPENAI_API_KEY 읽기

const app = express();
const port = 3000;

// 미들웨어
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // 정적 파일 제공 (index.html, fonts 등)

// OpenAI 초기화
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// 🔹 감정 분석 API
app.post('/api/emotion', async (req, res) => {
  try {
    const userInput = req.body.input;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: '사용자의 감정을 하나의 감정 키워드(예: 행복, 슬픔, 피곤 등)로 요약해 주세요. 키워드 하나만 반환하세요.',
        },
        { role: 'user', content: `지금 기분: ${userInput}` },
      ],
      temperature: 0.7,
    });

    const emotion = completion.choices?.[0]?.message?.content?.trim();
    console.log('감정 분석 결과:', emotion);
    if (!emotion) throw new Error('GPT 응답이 없습니다.');

    res.json({ emotion });
  } catch (error) {
    console.error('❌ 감정 분석 실패:', error);
    res.status(500).json({ error: '감정 분석 실패', detail: error.message });
  }
});

// 🔹 노래 추천 API
app.post('/api/recommend', async (req, res) => {
  try {
    const emotion = req.body.emotion;
    const prompt = `감정 "${emotion}"에 어울리는 한국어 노래 3곡을 추천해 주세요. 형식은 "제목 - 아티스트"로 해주세요.`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.8,
    });

    const responseText = completion.choices?.[0]?.message?.content?.trim();
    console.log('GPT 추천 응답:\n', responseText);
    if (!responseText) throw new Error('GPT 추천 응답이 비어 있습니다.');

    const lines = responseText
      .split('\n')
      .map(line => {
        const [title, artist] = line.split(' - ');
        return {
          title: title?.trim(),
          artist: artist?.trim(),
        };
      })
      .filter(song => song.title && song.artist);

    res.json(lines.slice(0, 3));
  } catch (error) {
    console.error('❌ 노래 추천 실패:', error);
    res.status(500).json({ error: '노래 추천 실패', detail: error.message });
  }
});

// 서버 시작
app.listen(port, () => {
  console.log(`✅ 서버 실행 중: http://localhost:${port}`);
});
